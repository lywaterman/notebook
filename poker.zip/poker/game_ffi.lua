local ffi = require("ffi")

math.randomseed(os.time())

function print_r (t, name, indent)
  local tableList = {}
  function table_r (t, name, indent, full)
    local serial=string.len(full) == 0 and name
    or type(name)~="number" and '["'..tostring(name)..'"]' or '['..name..']'
    io.write(indent,serial,' = ')
    if type(t) == "table" then
      if tableList[t] ~= nil then io.write('{}; -- ',tableList[t],' (self reference)\n\r')
      else
        tableList[t]=full..serial
        if next(t) then -- Table not empty
          io.write('{\n\r')
          for key,value in pairs(t) do table_r(value,key,indent..'\t',full..serial) end
          io.write(indent,'};\n\r')
        else io.write('{};\n\r') end
      end
    else io.write(type(t)~="number" and type(t)~="boolean" and '"'..tostring(t)..'"'
      or tostring(t),';\n\r') end
    end
    table_r(t,name or '__unnamed__',indent or '','')
  end

local print = function( ... )
    local var = ""
    for k, v in ipairs({...}) do
        var = var .. tostring(v)
    end

    var = string.gsub( var, '\n', '\r' )
    var = var .. '\r'

    print( var )
end

module("game_ffi", package.seeall)

type_desc = {
    "单张",
    "顺子",
    "对子",
    "连对",
    "三张",
    "连三张",
    "三带一",
    "连三带一",
    "三带二",
    "连三带二",
    "连四（两个炸弹废了）",
    "四带二",
    "连四带二",
    "四带四",
    "连四带四",
    "炸弹",
  }


ffi.cdef[[
// poker unit
typedef enum POKER_UNIT_t {
    P3,
    P4,
    P5,
    P6,
    P7,
    P8,
    P9,
    P10,
    PJ,
    PQ,
    PK,
    PA,
    P2,
    PJOKER0,
    PJOKER1
} POKER_UNIT;

// the color of poker
typedef enum POKER_CLR_t {
    SPADE,
    HEART,
    CLUB,
    DIAMOND,
    JOKER0,
    JOKER1
} POKER_CLR;

// the poker card element
typedef struct POKER_t {
    POKER_UNIT      unit;
    POKER_CLR       color;
    int             value;
} POKER;

typedef enum {
    INVALID_TYPE = 0,
    SINGLE,                 // 单张
    SERIES,                 // 顺子
    PAIR,                   // 对子
    SERIES_PAIR,            // 连对
    TRIANGLE,               // 三张
    SERIES_TRIANGLE,        // 连三张
    THREE_PLUS_ONE,         // 三带一
    SERIES_THREE_PLUS_ONE,  // 连三带一
    THREE_PLUS_TWO,         // 三带二
    SERIES_THREE_PLUS_TWO,  // 连三带二
    SERIES_FOUR,            // 连四（两个炸弹废了）
    FOUR_PLUS_TWO,          // 四带二
    SERIES_FOUR_PLUS_TWO,   // 连四带二
    FOUR_PLUS_FOUR,         // 四带四
    SERIES_FOUR_PLUS_FOUR,  // 连四带四
    BOMB,                   // 炸弹
} POKER_TYPE;

  typedef struct POKER_PROPERTY_s {int type; int value; int num; } POKER_PROPERTY;

  char c_poker_index_to_char(int index);

  void c_get_poker_property(POKER_PROPERTY* pp, int seq[40], int len);

  bool c_can_follow_poker(POKER_PROPERTY* pp, int vec[40], int num, POKER_PROPERTY* req);
  bool c_get_poker_hint(int times, int vec[40], int num, POKER_PROPERTY* req, POKER_PROPERTY* out, int out_vec[40]);

	int printf(const char *fmt, ...);

	void test_ffi();
// 单张
typedef struct HT_SINGLE_t {
    int     idx;
    int     value;
} HT_SINGLE;

// 对子
typedef struct HT_PAIR_t {
    int     idx0;
    int     idx1;
    int     value;
} HT_PAIR;

// 三张
typedef struct HT_TRIANGLE_t {
    int     idx0;
    int     idx1;
    int     idx2;
    int     value;
} HT_TRIANGLE;

// 四张
typedef struct HT_FOUR_t {
    int     idx0;
    int     idx1;
    int     idx2;
    int     idx3;
    int     value;
} HT_FOUR;

// 顺子
typedef struct HT_SERIES_t {
    int     idx[12];
    int     num;
    int     value;
} HT_SERIES;

// 连对
typedef struct HT_SERIES_PAIR_t {
    int     idx[20];
    int     num;
    int     value;
} HT_SERIES_PAIR;

// 三张
typedef struct HT_SERIES_TRIANGLE_t {
    int     idx[18];
    int     num;
    int     value;
} HT_SERIES_TRIANGLE;

// 连四
typedef struct HT_SERIES_FOUR_t {
    int     idx[20];
    int     num;
    int     value;
} HT_SERIES_FOUR;

// 双王炸弹
typedef struct HT_KINGBOMB_t {
    int     idx0;
    int     idx1;
    int     value;
} HT_KINGBOMB;

typedef struct POKER_CLASS_TABLE_t {
    int             builded;        // whether the PCT has been builded
    int             count;          // current poker cards num

    HT_SINGLE       one[14];        // single (13 singles at most)
    int             num1;           // [single] COUNT

    HT_PAIR         two[10];        // pair (10 pairs at most)
    int             num2;           // [pair] COUNT

    HT_TRIANGLE     three[6];       // triangle (6 triangles at most)
    int             num3;           // [triangle] COUNT

    HT_FOUR         four[5];        // four (5 fours at most)
    int             num4;           // [four] COUNT

    HT_KINGBOMB     kingbomb;       // king bomb
    int             has_king_bomb;  // indicate whether exists king bomb

    HT_SERIES       sone[2];        // series one (2 separate series at most)
    int             num11;          // [series one] COUNT

    HT_SERIES_PAIR      stwo[3];    // series two ( 3 separate series two at most)
    int                 num22;      // [series two] COUNT

    HT_SERIES_TRIANGLE  sthree[3];  // series three ( 3 separate series three at most)
    int                 num33;      // [series three] COUNT

    HT_SERIES_FOUR      sfour[2];   // series four ( 2 separate series four at most)
    int                 num44;      // [series four] COUNT
} POKER_CLASS_TABLE;

  bool c_build_poker_class_table(POKER_CLASS_TABLE* pct, int vec[40], int num);
	]]

ffi.C.printf("Hello %s!\n\r", "world")

game_luapath = "/root/LandOwner2/server/game/priv/lua/" 

local poker_lib = ffi.load(game_luapath .. "c/libpoker.so")

function get_poker_property(seq)

  if #seq == 0 then
    return nil
  end

  sort_table(seq)

	local seq_arr 	  = ffi.new("int[40]", {})
  for i, v in ipairs(seq) do
    seq_arr[i-1] = (v - 1)
  end

  local prop = ffi.new("POKER_PROPERTY", {})
	poker_lib.c_get_poker_property(prop, seq_arr, #seq)
  
  return prop
end

function can_follow_poker(seq, last_prop)
  if #seq == 0 then
    assert(false)
  end

  sort_table(seq)

  if last_prop == nil then
    return true, get_poker_property(seq)
  end
    
  local seq_arr 	  = ffi.new("int[40]", {})
  for i, v in ipairs(seq) do
    seq_arr[i-1] = (v - 1)
  end

  local prop = ffi.new("POKER_PROPERTY", {})
  
  return poker_lib.c_can_follow_poker(prop, seq_arr, #seq, last_prop), prop
end

function get_poker_hint(times, all_seq, last_prop)
  if #all_seq == 0 then
    assert(false)
  end
  
  sort_table(all_seq)

  if last_prop == nil then
    return true, get_poker_property({all_seq[1]}), {1}
  end

  local all_seq_arr 	  = ffi.new("int[40]", {})
  for i, v in ipairs(all_seq) do
    all_seq_arr[i-1] = (v - 1)
  end

  local prop = ffi.new("POKER_PROPERTY", {})
  local out_seq_arr = ffi.new("int[40]", {})
  local out_seq = {}

  local can_chu = poker_lib.c_get_poker_hint(times-1, all_seq_arr, #all_seq, last_prop, prop, out_seq_arr)

  if can_chu then
    local num = prop.num
    for i=0, (num-1) do
      table.insert(out_seq, (out_seq_arr[i]+1))
    end
  end

  return can_chu, prop, out_seq
end

function get_poker_desc(all_seq)
  local seq_desc = {}
  
  for i, v in ipairs(all_seq) do
    local char= poker_lib.c_poker_index_to_char(v-1)
    
    local aa = {"小王", "大王"}
    if char ~= 1 and char ~= 2 and v ~= 999 then
      table.insert(seq_desc, string.char(char))
    elseif v == 999 then
      table.insert(seq_desc, "-------------------------------")
    else
      table.insert(seq_desc, aa[char])
    end
  end

  return seq_desc
end

function split_poker(all_seq)
  if #all_seq == 0 then
    assert(false)
  end
  
  sort_table(all_seq)

  local all_seq_arr 	  = ffi.new("int[40]", {})
  for i, v in ipairs(all_seq) do
    all_seq_arr[i-1] = (v - 1)
  end

  local cltable = ffi.new("POKER_CLASS_TABLE", {})

  poker_lib.c_build_poker_class_table(cltable, all_seq_arr, #all_seq) 

  print_one(cltable, all_seq)
  print_two(cltable, all_seq)
  print_three(cltable, all_seq)
  print_four(cltable, all_seq)
  print_kings(cltable, all_seq)
  print_sone(cltable, all_seq)
  print_stwo(cltable, all_seq)
  print_sthree(cltable, all_seq)
end

function sort_table(t)
  table.sort(t, function (a, b) return a < b end)
end

function print_one(cltable, all_seq)
  print("oneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
  local one_seq = {}
  for i=1, cltable.num1 do
    table.insert(one_seq, all_seq[(cltable.one[i-1].idx)+1])
  end
  print_r(get_poker_desc(one_seq))

  return one_seq
end

function print_two(cltable, all_seq)
  print("twoooooooooooooooooooooooooooooooooooooo")
  local two_seq = {}
  local result = {}
  for i=1, cltable.num2 do
    result[i] = {}
    table.insert(result[i], all_seq[(cltable.two[i-1].idx0)+1])
    table.insert(result[i], all_seq[(cltable.two[i-1].idx1)+1])

    table.insert(two_seq, all_seq[(cltable.two[i-1].idx0)+1])
    table.insert(two_seq, all_seq[(cltable.two[i-1].idx1)+1])
  end
  print_r(get_poker_desc(two_seq))

  return result
end

function print_three(cltable, all_seq)
  print("threeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
  local three_seq = {}
  local result = {}
  for i=1, cltable.num3 do
    result[i] = {}
    table.insert(result[i], all_seq[(cltable.three[i-1].idx0)+1])
    table.insert(result[i], all_seq[(cltable.three[i-1].idx1)+1])
    table.insert(result[i], all_seq[(cltable.three[i-1].idx2)+1])

    table.insert(three_seq, all_seq[(cltable.three[i-1].idx0)+1])
    table.insert(three_seq, all_seq[(cltable.three[i-1].idx1)+1])
    table.insert(three_seq, all_seq[(cltable.three[i-1].idx2)+1])
  end

  print_r(get_poker_desc(three_seq))

  return result
end

function print_four(cltable, all_seq)
  print("fourrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr")
  local four_seq = {}
  local result = {}

  for i=1, cltable.num4 do
    result[i] = {}
    table.insert(result[i], all_seq[(cltable.four[i-1].idx0)+1])
    table.insert(result[i], all_seq[(cltable.four[i-1].idx1)+1])
    table.insert(result[i], all_seq[(cltable.four[i-1].idx2)+1])
    table.insert(result[i], all_seq[(cltable.four[i-1].idx3)+1])
    table.insert(result, a)

    table.insert(four_seq, all_seq[(cltable.four[i-1].idx0)+1])
    table.insert(four_seq, all_seq[(cltable.four[i-1].idx1)+1])
    table.insert(four_seq, all_seq[(cltable.four[i-1].idx2)+1])
    table.insert(four_seq, all_seq[(cltable.four[i-1].idx3)+1])
  end

  print_r(get_poker_desc(four_seq))

  return result
end

--------------------------------------------------------------------------------------------

function print_kings(cltable, all_seq)
  print("kingbombbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")
  local two_seq = {}
  for i=1, cltable.has_king_bomb do
    table.insert(two_seq, all_seq[(cltable.kingbomb.idx0)+1])
    table.insert(two_seq, all_seq[(cltable.kingbomb.idx1)+1])
  end

  print_r(get_poker_desc(two_seq))

  return two_seq
end


function print_sone(cltable, all_seq)
  print("soneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
  
  local seq = {}

  local result = {}
  for i=1, cltable.num11  do
    for i1=1, cltable.sone[i-1].num do
      result[i] = {}
      table.insert(result[i], all_seq[(cltable.sone[i-1].idx[i1-1])+1])

      table.insert(seq, all_seq[(cltable.sone[i-1].idx[i1-1])+1])
    end

    table.insert(seq, 999)
  end
  
  print_r(get_poker_desc(seq))

  return result
end

function print_stwo(cltable, all_seq)
  print("stwoooooooooooooooooooooooooooooooooooooooooooooooooooooo")
  
  local seq = {}
  local result = {}
  for i=1, cltable.num22  do
    for i1=1, cltable.stwo[i-1].num do
      result[i] = {}
      table.insert(result[i], all_seq[(cltable.stwo[i-1].idx[i1-1])+1])

      table.insert(seq, all_seq[(cltable.stwo[i-1].idx[i1-1])+1])
    end

    table.insert(seq, 999)
  end
 
  print_r(get_poker_desc(seq))

  return result
end


function print_sthree(cltable, all_seq)
  print("sthreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
  
  local seq = {}
  local result = {}
  for i=1, cltable.num33  do
    for i1=1, cltable.sthree[i-1].num do
      result[i] = {}
      table.insert(result[i], all_seq[(cltable.sthree[i-1].idx[i1-1])+1])

      table.insert(seq, all_seq[(cltable.sthree[i-1].idx[i1-1])+1])
    end

    table.insert(seq, 999)
  end
  
  print_r(get_poker_desc(seq))

  return result
end


local landowner_module = require("landowner")
local poker = landowner_module.normal_shuffle_tiles()

local all_seq = {}

for i=1, 20 do
  table.insert(all_seq, landowner_module.deal_poker(poker))
end

sort_table(all_seq)

print_r(get_poker_desc(all_seq))


split_poker(all_seq)

--local aa = get_poker_property(
--{
--    [1] = 31,
--      [2] = 28,
--        [3] = 24,
--          [4] = 18,
--            [5] = 14,
--              [6] = 11,
--                [7] = 8,
--                  [8] = 1,
--                }
--)
--
--
