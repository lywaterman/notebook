//
// Quick sort
//

#pragma once

void quick_sort(int a[], int low, int high);
